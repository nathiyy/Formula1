
// Define variáveis globais
let saldo = 100;
const valorApostaInput = document.getElementById('valorAposta');
const pilotosSelect = document.getElementById('pilotos');
const resultadoDiv = document.getElementById('resultado');
const corridaDiv = document.getElementById('corrida');
const carros = document.querySelectorAll('.carro'); // Seleciona todos os carros

// Adiciona um evento de clique ao botão "Apostar"
document.getElementById('apostar').addEventListener('click', function() {
    // Obtém o valor da aposta e o piloto escolhido pelo jogador
    const valorAposta = parseInt(valorApostaInput.value);
    const pilotoEscolhido = parseInt(pilotosSelect.value);

    // Verifica se o valor da aposta é válido
    if (isNaN(valorAposta) || valorAposta < 5 || valorAposta > saldo) {
        alert('Valor da aposta inválido!');
        return;
    }

    // Reduz o saldo do jogador pelo valor da aposta
    saldo -= valorAposta;
    document.getElementById('saldo').textContent = saldo;

    // Define a posição inicial e a velocidade para cada carro
    carros.forEach((carro, index) => {
        const distanciaInicial = Math.random() * (corridaDiv.offsetWidth - 100);
        const velocidade = Math.floor(Math.random() * 10) + 1;
        carro.style.transition = 'left 2s linear'; // Adiciona uma transição suave para o movimento do carro
        carro.style.left = `${distanciaInicial}px`; // Move o carro para a posição inicial
        carro.velocidade = velocidade; // Define a velocidade do carro

        // Inicia a corrida para cada carro
        corrida(carro, pilotoEscolhido, valorAposta);
    });
});

// Função para simular a corrida para um carro específico
function corrida(carro, pilotoEscolhido, valorAposta) {
    const distanciaTotal = corridaDiv.offsetWidth - 100; // Define a distância total da corrida
    const tempoParaChegar = distanciaTotal / carro.velocidade; // Calcula o tempo que o carro levará para chegar

    // Move o carro até a linha de chegada
    setTimeout(() => {
        carro.style.left = `${distanciaTotal}px`; // Move o carro para a posição final

        // Verifica se o carro cruzou a linha de chegada
        setTimeout(() => {
            if (carro.offsetLeft >= distanciaTotal) {
                if (carro.id === `carro${pilotoEscolhido}`) {
                    resultadoDiv.textContent = 'Você ganhou!';
                    saldo += valorAposta * 2;
                } else {
                    resultadoDiv.textContent = 'Você perdeu!';
                }
                document.getElementById('saldo').textContent = saldo;
            }
        }, 2000); // Espera 2 segundos para verificar o resultado
    }, tempoParaChegar * 1000); // Espera o tempo necessário para o carro chegar
}